window.mcwidget = {"appId":"532160876956612","pageId":"1720923091462112","page_name":"Payo - COD Gateway","fb_page_id":"1720923091462112","widget_phone":null,"sms_channel_connected":false,"widgets":[],"widgetLocale":"en_US","defaultSize":0,"fbSDKVersion":"v12.0","whitelist":["e04a45f0a505569fddc714decd22a84e8cb421b628b371dd70f2ca7035eac346","f2cbfeda670dc91d10651057f2d9c1f9010175cf28059cfc43337b7d2c6f3f4d","36d89a1ba8cf52036f81a963c230938b18519267ee2a0e7203de79da8f03be17","798041ee1e88ad14f69d6b3f66393b8f13c475c0c879e5f3e9a9b5dbc111a186","5b16139f5448d4ad178142e5dbd79ce38a3ac742fde8eed920bef75bc11b9494","d9124edf47d82e79785859c53458e6c2226c6c154a3c21519143d9c4bd4b6eb9"],"smsModalConsentText":"Please note that by typing in your phone number in the field above you are agreeing to receive autodialed personal and marketing text messages to your mobile number. Consent is not required for purchase. Message and data rates may apply. Reply “STOP” by SMS to cancel."};


    (function(d, s, id){
        var host = 'mccdn.me';

        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) { return; }
        js = d.createElement(s); js.id = id;
        js.src = '//' + host + '/assets/js/widget.js';
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'mcwidget-core'));

            